<?php
/*
* My Theme Function
*/

// ALl Default theme function here
include_once('inc/default.php');


// Theme CSS and jQuery File calling
include_once('inc/enqueue.php');


//Theme Function
include_once('inc/theme_function.php');


// Menu Register
include_once('inc/menu_register.php');

